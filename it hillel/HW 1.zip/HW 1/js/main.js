alert("" + 1 + 0); //10
alert("" - 1 + 0);  //-1    
alert(true + false);    //1
alert(6 / "3"); //2
alert("2" * "3");   //6
alert(4 + 5 + "px"); //9px
alert("$" + 4 + 5); //$45
alert("4" - 2); //2
alert("4px" - 2);   //NaN
alert(7 / 0);   //Infinity
alert(" -9 " + 5);  //"-9 5"
alert(" -9 " - 5);  //-14
alert(null + 1);    //1
alert(undefined + 1);   //NaN
alert(" \t \n" - 2);    //-2

alert(10 && 'undefined' || null && -1); //undefined

alert(' ' && true && 'false' || 0 && 7); //false

alert(false && null || NaN && Infinity || 0); //0

alert(10 / -0 && 9 - '9cm' || 11 % 2); //1